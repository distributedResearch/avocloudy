#ABC_X.xml X is the number of volunteer nodes e.g., acoLoadBalancing_100.xml is aco with 100 whereas acoLoadBalancing_500.xml with 500

#scenarios for the following number of volunteer nodes:
# 100
# 500
# 1000
# 1500
# 2000
# 2500
# 3000

#TO RUN: ACO
java -jar multivestaCloudy.jar -c -m scenario/acoLoadBalancing_100.xml -l 6 -f multiquatex/allPerformanceIndicatorsEnd.quatex -bs 6 -a 0.05 -se it.imtlucca.cloudyscience.multivesta.CloudyScienceDeusStateEvaluator -osws WHOLESIMULATION -sots 12345 -sd deus.DeusState -ms 100 -d1 0.0001 > output_acoLoadBalancing_100
java -jar multivestaCloudy.jar -c -m scenario/acoLoadBalancing_500.xml -l 2 -f multiquatex/allPerformanceIndicatorsEnd.quatex -bs 6 -a 0.05 -se it.imtlucca.cloudyscience.multivesta.CloudyScienceDeusStateEvaluator -osws WHOLESIMULATION -sots 12345 -sd deus.DeusState -ms 100 -d1 0.0001 > output_acoLoadBalancing_500.txt


#TO RUN: RANDOM
java -jar multivestaCloudy.jar -c -m scenario/random_100.xml -l 6 -f multiquatex/allPerformanceIndicatorsEnd.quatex -bs 6 -a 0.05 -se it.imtlucca.cloudyscience.multivesta.CloudyScienceDeusStateEvaluator -osws WHOLESIMULATION -sots 12345 -sd deus.DeusState -ms 100 -d1 0.0001 > output_random_100.txt

#TO RUN: ACO - PARTITIONED
java -jar multivestaCloudy.jar -c -m scenario/acoPartitioning_100.xml -l 6 -f multiquatex/allPerformanceIndicatorsEnd.quatex -bs 6 -a 0.05 -se it.imtlucca.cloudyscience.multivesta.CloudyScienceDeusStateEvaluator -osws WHOLESIMULATION -sots 12345 -sd deus.DeusState -ms 100 -d1 0.0001 > output_acoPartitioning_100.txt

#TO RUN: GREEDY ORACLE
java -jar multivestaCloudy.jar -c -m scenario/greedyOracle_100.xml -l 6 -f multiquatex/allPerformanceIndicatorsEnd.quatex -bs 6 -a 0.05 -se it.imtlucca.cloudyscience.multivesta.CloudyScienceDeusStateEvaluator -osws WHOLESIMULATION -sots 12345 -sd deus.DeusState -ms 100 -d1 0.0001 > output_greedyOracle_100.txt